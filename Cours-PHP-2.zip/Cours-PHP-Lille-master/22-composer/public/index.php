<?php 

include_once __DIR__ ."/../vendor/autoload.php";

$fruits_str = "          Pommes vertes         ,         Poires       , Bananes            ";
// $fruits_arr = explode(",", $fruits_str);

// foreach ($fruits_arr as $key => $value)
// {
//     $fruits_arr[ $key ] = trim($value);
// }

?>





<pre><?php print_r($fruits_str) ?></pre>
<hr>
<pre><?php print_r($fruits_arr) ?></pre>

<?php foreach($fruits_arr as $fruit): ?>
<pre><?= $fruit ?></pre>
<?php endforeach ?>
