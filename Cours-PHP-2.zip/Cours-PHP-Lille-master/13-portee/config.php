<?php

$passwd = "123456";