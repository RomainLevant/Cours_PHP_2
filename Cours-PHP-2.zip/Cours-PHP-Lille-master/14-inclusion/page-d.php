<h3>Page D</h3>
<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Tenetur labore laboriosam obcaecati sunt accusamus consectetur atque neque cum in suscipit voluptates, similique asperiores beatae pariatur nam dignissimos, odit deleniti quod?</p>


<?php 

function fnc_de_la_page_D()
{
    // elle ne fait rien
}