<h3>Config</h3>

<?php 

$db_user = "root";
$db_pass = "12345";