<?php 

// On force l'affichage des messages d'erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// Inclure les classes parent
include "Vehicule.php";

// Inclure les classes enfants
include "Voiture.php";
include "Moto.php";

include "Driver.php";



$voiture_1  = new Voiture("Tesla", "3", "Rouge");
$moto_1     = new Moto("Kawazaki", "ER-6N", "Vert Pomme");

$driver_1 = new Driver("bOB", "SpOnGe");
$driver_2 = new Driver("wonder", "woman");

?>

<h1>Vehicules</h1>

<h2>Voiture 1</h2>
<div>Marque : <?= $voiture_1->getBrand() ?></div>
<div>Modèle : <?= $voiture_1->getModel() ?></div>
<div>Couleur : <?= $voiture_1->getColor() ?></div>
<div>ethylotest : <?= $voiture_1->ethylotest(5) ?></div>

<h2>Moto 1</h2>
<div>Marque : <?= $moto_1->getBrand() ?></div>
<div>Modèle : <?= $moto_1->getModel() ?></div>
<div>Couleur : <?= $moto_1->getColor() ?></div>
<div>ethylotest : <?= $moto_1->ethylotest() ?></div>

<h2>Dirver 1</h2>
<div>Prénom : <?= $driver_1->getFirstname() ?></div>
<div>NOM : <?= $driver_1->getLastname() ?></div>

<h2>Dirver 2</h2>
<div>Prénom : <?= $driver_2->getFirstname() ?></div>
<div>NOM : <?= $driver_2->getLastname() ?></div>


<h2>Affectation des conduteurs</h2>
<?php $voiture_1->setDriver( $driver_1 ) ?>

<h3>Conducteur de Voiture 1</h3>
<div>Prénom : <?php // echo $voiture_1->getDriver()->getFirstname() ?></div>
<div>NOM : <?php // echo $voiture_1->getDriver()->getLastname() ?></div>


<h2>Demarrage de la voiture</h2>
<div>Voiture démarrée ? <?= $voiture_1->getIsStarted() ? "Oui" : "Non" ?></div>
<?php $voiture_1->start() ?>
<div>Voiture démarrée ? <?= $voiture_1->getIsStarted() ? "Oui" : "Non" ?></div>
<div>Vitesse de la voiture : <?= $voiture_1->getSpeed() ?> Km/h</div>

<?php $voiture_1->accelerate() ?>
<div>Vitesse de la voiture : <?= $voiture_1->getSpeed() ?> Km/h</div>
<?php $voiture_1->accelerate()->accelerate()->accelerate()->accelerate() ?>
<div>Vitesse de la voiture : <?= $voiture_1->getSpeed() ?> Km/h</div>
<?php //$voiture_1->accelerate()->accelerate()->accelerate()->accelerate()->accelerate()->accelerate()->accelerate()->accelerate()->accelerate()->accelerate()->accelerate()->accelerate()->accelerate()->accelerate()->accelerate()->accelerate() ?>
<div>Vitesse de la voiture : <?= $voiture_1->getSpeed() ?> Km/h</div>

<h3>On tourne.. à droite !</h3>
<?php $voiture_1->turn("right") ?>



<h2>On ralenti..</h2>
<div>Vitesse de la voiture : <?= $voiture_1->getSpeed() ?> Km/h</div>
<?php $voiture_1->decelerate() ?>
<div>Vitesse de la voiture : <?= $voiture_1->getSpeed() ?> Km/h</div>
<?php $voiture_1->decelerate() ?>
<div>Vitesse de la voiture : <?= $voiture_1->getSpeed() ?> Km/h</div>



<h3>On tourne.. à droite !</h3>

<?php $voiture_1->turn("right") ?>



<h3>Arret du vehicule</h3>
<div>Voiture démarrée ? <?= $voiture_1->getIsStarted() ? "Oui" : "Non" ?></div>
<?php $voiture_1->stop() ?>
<div>Voiture démarrée ? <?= $voiture_1->getIsStarted() ? "Oui" : "Non" ?></div>



<h2>On ralenti..</h2>
<div>Vitesse de la voiture : <?= $voiture_1->getSpeed() ?> Km/h</div>
<?php $voiture_1->decelerate() ?>
<div>Vitesse de la voiture : <?= $voiture_1->getSpeed() ?> Km/h</div>

<h3>Arret du vehicule</h3>
<div>Voiture démarrée ? <?= $voiture_1->getIsStarted() ? "Oui" : "Non" ?></div>
<?php $voiture_1->stop() ?>
<div>Voiture démarrée ? <?= $voiture_1->getIsStarted() ? "Oui" : "Non" ?></div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

