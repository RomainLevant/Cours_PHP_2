<?php 

abstract class Vehicule
{
    /**
     * Vitesse maximum autorisée
     * 
     * @var int
     */
    const ALLOWED_MAX_SPEED = 80;

    /**
     * Vehicule Brand
     *
     * @var string
     */
    private $brand;

    /**
     * Vehicule Model
     *
     * @var string
     */
    private $model;

    /**
     * Vehicule Color
     *
     * @var string
     */
    private $color;

    /**
     * Vehicule driver
     *
     * @var Driver
     */
    private $driver;

    /**
     * Vehicule start / stop status
     *
     * @var boolean
     */
    private $isStarted = false;

    /**
     * Vehicule speed
     *
     * @var integer
     */
    private $speed = 0;



    // Construct
    // --

    // Contructeur :
    // Definition des propriété $brand, $model, $color 
    // Usage : new Voiture("Tesla", "3", "Rouge")
    public function __construct(string $brand, string $model, string $color)
    {
        $this->brand = $brand;
        $this->model = $model;
        $this->color = $color;
    }


    // Getter / Setter
    // --


    /**
     * Get the value of brand
     * 
     * @return string
     */ 
    public function getBrand(): string
    {
        return $this->brand;
    }
    
    /**
     * Get the value of model
     * 
     * @return string
     */ 
    public function getModel(): string
    {
        return $this->model;
    }

    /**
     * Get the value of color
     * 
     * @return string
     */ 
    public function getColor(): string
    {
        return $this->color;
    }

    /**
     * Get vehicule driver
     *
     * @return  Driver
     */ 
    public function getDriver(): ?Driver
    {
        return $this->driver;
    }

    /**
     * Set vehicule driver
     *
     * @param  Driver  $driver  Vehicule driver
     *
     * @return  self
     */ 
    public function setDriver(Driver $driver): self
    {
        $this->driver = $driver;

        return $this;
    }

    /**
     * Get vehicule start / stop status
     *
     * @return  boolean
     */ 
    public function getIsStarted()
    {
        return $this->isStarted;
    }

    /**
     * Get vehicule speed
     *
     * @return  integer
     */ 
    public function getSpeed(): int
    {
        return $this->speed;
    }







    /**
     * Set start stop status
     *
     * @return void
     */
    public function start(): self
    {
        if ($this->driver)
        {
            $this->isStarted = true;
        }

        return $this;
    }

    /**
     * Set speed property ++ (5km/h)
     *
     * @return void
     */
    public function accelerate(): self
    {
        if ($this->isStarted)
        {
            if ($this->speed < self::ALLOWED_MAX_SPEED)
            {
                $this->speed += 5;
            }
            else
            {
                $this->alert("Vitesse max atteinte !");
            }
        }

        return $this;
    }

    /**
     * Set speed property -- (10km/h)
     *
     * @return self
     */
    public function decelerate(): self
    {
        $this->speed -= 10;

        if ($this->speed < 0)
        {
            $this->speed = 0;
        }

        return $this;
    }

    /**
     * Turn right or left
     *
     * @param string $direction right|left
     * @return void
     */
    public function turn(string $direction)
    {
        if ($this->speed <= 0)
        {
            $this->alert("Ne peu pas tourner à l'arret");
        }
        elseif ($this->speed > 10)
        {
            $this->alert("Oula !! tu vas trop vite.");
        }
        else 
        {
            $this->alert("Tourne : $direction");
        }

        // switch (true)
        // {
        //     case $this->speed <= 0:
        //         $this->alert("Ne peu pas tourner à l'arret");
        //     break;

        //     case $this->speed > 10:
        //         $this->alert("Oula !! tu vas trop vite.");
        //     break;

        //     default:
        //         $this->alert("Tourne : $direction");
        // }
    }

    public function stop()
    {
        if ($this->speed == 0 && $this->isStarted)
        {
            $this->isStarted = false;
        }

        else 
        {
            $this->alert("On ne peut pas arreter le véhicule !");
        }
    }

    /**
     * Show alerty Message
     *
     * @param string $message
     * @return self
     */
    private function alert(string $message): self
    {
        echo "<fieldset>".$message ."</fieldset><br>";

        return $this;
    }

    abstract public function ethylotest(int $seconds);

}