<?php 

class Voiture extends Vehicule 
{
    const WHEELS = 4;

    public function ethylotest(int $s)
    {
        echo "souffle $s secondes dans le ballon !";
    }
}