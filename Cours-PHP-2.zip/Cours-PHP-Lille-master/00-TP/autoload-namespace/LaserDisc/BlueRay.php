<?php 

namespace LaserDisc;

class BlueRay extends Laser
{
    public function capacity()
    {
        return "25 Go";
    }
    
    public function caracteristique ()
    {
        return parent::caracteristique() . $this->capacity();
    }
}