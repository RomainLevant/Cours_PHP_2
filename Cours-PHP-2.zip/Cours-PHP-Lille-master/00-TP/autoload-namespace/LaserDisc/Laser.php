<?php

namespace LaserDisc;

abstract class Laser 
{
    public function caracteristique ()
    {
        return "Disque Laser<br>";
    }
}