<?php 

namespace LaserDisc;

class CD extends Laser 
{
    public function capacity()
    {
        return "700 Mb";
    }

    public function caracteristique ()
    {
        return parent::caracteristique() . $this->capacity();
    }

    /**
     * Undocumented function
     *
     * @see self::caracteristique
     * @version 5.0
     * @since 3.0
     */
    public function info()
    {
        return $this->caracteristique();
    }
}