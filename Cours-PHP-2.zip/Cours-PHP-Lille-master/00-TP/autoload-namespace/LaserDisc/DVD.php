<?php 

namespace LaserDisc;

class DVD extends Laser
{
    public function capacity()
    {
        return "4,7 Go";
    }
    
    public function caracteristique ()
    {
        return parent::caracteristique() . $this->capacity();
    }
}