<?php 

// Autoload
// --

function myAutoload(string $class)
{
    $class = $class.".php";
    $class = str_replace("\\", "/", $class);

    include_once $class;
}
spl_autoload_register("myAutoload");



// Use case
// --

use \LaserDisc\CD;
use \LaserDisc\DVD;
use \LaserDisc\BlueRay;


// Instances
// --

$cd = new CD;
$dvd = new DVD;
$blueRay = new BLUERAY;


// Show data
// --

echo $cd->caracteristique()."<hr>";
echo $dvd->caracteristique()."<hr>";
echo $blueRay->caracteristique()."<hr>";