<?php
/**
 * TP PHP POO
 * 
 * Chainage de méthodes
 * 
 * Partie 1 : Déclaration de la classe
 * Partie 2 : Utilisation de la classe
 */


/**
 * Partie 1 : Déclaration de la classe
 */

class Text
{
    /**
     * La propriété $text sert à stocker la chaine qui sera manipulé 
     * puis affiché
     * 
     * @var string
     */
    public $text;

    /**
     * Méthode qui affecte le texte à manipuler à la propriété $this->text
     *
     * @param string $text
     * @return self
     */
    public function set(string $text): self
    {
        $this->text = $text;

        return $this;
    }

    /**
     * Retourne le texte à afficher
     *
     * @return string
     */
    public function print(): string
    {
        return $this->text;
    }

    /**
     * Formate le texte en gras
     *
     * @return self
     */
    public function bold(): self
    {
        $this->text = "<b>$this->text</b>";

        return $this;
    }

    public function italic(): self
    {
        $this->text = "<i>$this->text</i>";

        return $this;
    }

    public function strike(): self
    {
        $this->text = "<s>$this->text</s>";

        return $this;
    }

}



/**
 * Partie 2 : Utilisation de la classe
 */

$hello = "Hello World";
$text = new Text;




// // Affiche le texte (simple)
echo $text->set($hello)->print()."<br>\n";

// Affiche le texte avec les balises HTML <b></b>
echo $text->set($hello)->bold()->print()."<br>\n";

// Affiche le texte avec les balises HTML <i></i>
echo $text->set($hello)->italic()->print()."<br>\n";

// Affiche le texte avec les balises HTML <s></s>
echo $text->set($hello)->strike()->print()."<br>\n";

// Affiche le texte avec les mises en forme combinées
echo $text->set($hello)->italic()->bold()->strike()->print()."<br>\n";