<?php 
include_once "config/config.php";
include_once "config/db_connect.php";
include_once HEADER_PATH
?>
<!-- ======================================================================= -->

<h1>Nos Services</h1>

<!-- ======================================================================= -->
<?php include_once FOOTER_PATH ?>