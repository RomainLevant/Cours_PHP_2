<?php

class Voiture
{
    private $brand;
    private $model;

    public function __construct(string $brand, string $model)
    {
        $this->brand = $brand;
        $this->model = $model;
    }

    public function __destruct()
    {
        if (!empty($this->brand))
        {
            echo "Destructeur Marque = ".$this->brand."<br>";
        }

        if (!empty($this->model))
        {
            echo "Destructeur Modele = ".$this->model."<br>";
        }
    }

    public function getBrand()
    {
        return $this->brand;
    }

    public function getModel()
    {
        return $this->model;
    }
}