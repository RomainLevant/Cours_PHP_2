<?php

include_once "Voiture.php";

$voiture_1 = new Voiture("Tesla", "s90");


echo "INDEX Marque : " . $voiture_1->getBrand()."<br>";
echo "INDEX modele : " . $voiture_1->getModel()."<br>";



echo "La vie de la voiture<hr>";





echo "Et paf.. un accident.. <br>";


echo "<hr>";

echo (2+2) ."<br>";





echo "<hr>";


echo "<hr>";
echo "<hr>";
