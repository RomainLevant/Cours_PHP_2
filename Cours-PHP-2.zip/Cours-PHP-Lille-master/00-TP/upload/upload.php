<?php 

// On force l'affichage des messages d'erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === "POST")
{
    // Si l'image contient erreur
    if ($_FILES['photo']['error'] != 0)
    {
        die("Erreur sur le fichier image");
    }


    // Taille du fichier
    if ($_FILES['photo']['size'] > 200000)
    {
        die("Trop volumineux");
    }

    // Methode 1
    // copy($_FILES['photo']['tmp_name'], $_FILES['photo']['name']);

    // Methode 2
    $moved = move_uploaded_file($_FILES['photo']['tmp_name'], $_FILES['photo']['name']);
}