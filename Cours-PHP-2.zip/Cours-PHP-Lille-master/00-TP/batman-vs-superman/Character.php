<?php

class Character
{
    // Constantes
    // --

    /**
     * Level Novice
     * 
     * @var int
     */
    const NOVICE = 1;

    /**
     * Level Medium
     * 
     * @var int
     */
    const MEDIUM = 2;

    /**
     * Level Expert
     * 
     * @var int
     */
    const EXPERT = 3;


    // Properties
    // --

    /**
     * Character's name
     *
     * @var string
     */
    private $name;

    /**
     * Health point (point de vie)
     *
     * @default 100
     * @var int
     */
    private $hp = 100;

    /**
     * Character's eXPerience
     *
     * @var int
     */
    private $xp;


    // Methods
    // --

    public function __construct(string $name, int $xp)
    {
        // Set character's name
        $this->name = $name;

        // Set Character's XP
        $this->xp = $xp;
    }

    /**
     * Get the name of the character
     *
     * @return string
     */
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Get the Character's Heath Point
     *
     * @return integer
     */
    public function getHp(): int
    {
        return $this->hp;
    }

    /**
     * Set Health Point to a character
     *
     * @param integer $hp
     * @return self
     */
    public function setHp(int $hp): self
    {
        $this->hp = $hp;

        return $this;
    }

    /**
     * Get the Character's Experience
     *
     * @return integer
     */
    public function getXp(): int
    {
        return $this->xp;
    }

    /**
     * Say hello to another Character
     *
     * @param Character $opponent
     * @return string
     */
    public function sayHello(Character $opponent): string
    {
        return $this->name." salue ". $opponent->getName();
    }

    /**
     * Attack an opponent
     *
     * @param Character $opponent
     * @return self
     */
    public function attack(Character $opponent, int $coef = 1): self
    {
        switch ($this->xp)
        {
            case self::NOVICE: // 1
                $opponent->setHp( $opponent->getHp() - ($coef * 10) );
            break;

            case self::MEDIUM: // 2
                $opponent->setHp( $opponent->getHp() - ($coef * 20) );
            break;

            case self::EXPERT: // 3
                $opponent->setHp( $opponent->getHp() - ($coef * 30) );
            break;
        }

        return $this;
    }

    /**
     * Super Attack an opponent (attack x 2)
     *
     * @param Character $opponent
     * @return self
     */
    public function superAttack(Character $opponent): self
    {
        $this->attack( $opponent, 2 );

        return $this;
    }

    /**
     * A secret Attack set the opponent HP to 0, if the opponent HP less than 50
     *
     * @return self
     */
    public function secretAttack(Character $opponent): self
    {
        if ($opponent->getHp() < 50)
        {
            $opponent->setHp(0);
        }
        // else {
        //     echo "Echec de la super attaque !";
        // }

        return $this;
    }

    /**
     * Add 10 Health point to the character
     *
     * @return self
     */
    public function care(): self
    {
        // $this->setHp( $this->getHp() + 10 );
        $this->hp += 10;

        return $this;
    }

    /**
     * Level Up (+1) the character XP
     *
     * @return self
     */
    public function levelUp(): self
    {
        switch ($this->xp)
        {
            case self::NOVICE:
                $this->xp = self::MEDIUM;
            break;

            case self::MEDIUM:
                $this->xp = self::EXPERT;
            break;

            case self::EXPERT:
                // Rien à faire
            break;
        }

        return $this;
    }

}