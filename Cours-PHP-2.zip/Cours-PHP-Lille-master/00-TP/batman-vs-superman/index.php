<?php 

// Affichage des erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Inclure le fichier Character
include_once "Character.php";

$combattant_1 = new Character("Batman", Character::MEDIUM);
$combattant_2 = new Character("Superman", Character::NOVICE);

// Définition du titre du document
$title = "Baston : ".$combattant_1->getName()." Vs ".$combattant_2->getName()." !";

// Déclaration de la fonction stats qui permet d'affiche les stats des combattants
// Le combattant 1 ($player_1) est de type Character
// Le combattant 2 ($player_2) est de type Character
function stats(Character $player_1, Character $player_2): string
{
    // Initialle Player 1 
    $name_1 = substr($player_1->getName(), 0, 1).".";

    // Initialle Player 2
    $name_2 = substr($player_2->getName(), 0, 1).".";

    // Point de vie $player_1
    $hp_1 = $player_1->getHp();

    // Point de vie $player_2
    $hp_2 = $player_2->getHp();

    return "($name_1 $hp_1 - $name_2 $hp_2)";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
</head>
<body>
    
    <h1><?= $title ?></h1>

    <h2>Présentation</h2>

    <fieldset>
        <legend>Personnage 1</legend>
        <div>Nom : <?= $combattant_1->getName() ?></div>
        <div>Points de vie : <?= $combattant_1->getHp() ?></div>
        <div>Experience : <?= $combattant_1->getXp() ?></div>
    </fieldset>

    <fieldset>
        <legend>Personnage 2</legend>
        <div>Nom : <?= $combattant_2->getName() ?></div>
        <div>Points de vie : <?= $combattant_2->getHp() ?></div>
        <div>Experience : <?= $combattant_2->getXp() ?></div>
    </fieldset>

    <hr>

    <?=  stats($combattant_1, $combattant_2) ?>

    <hr>

    <h3>Salutation</h3>

    <div><?= $combattant_1->sayHello( $combattant_2 ) ?> <?=  stats($combattant_1, $combattant_2) ?></div>
    <div><?= $combattant_2->sayHello( $combattant_1 ) ?> <?=  stats($combattant_1, $combattant_2) ?></div>
    

    <h3>Batman attaque Superman</h3>
    <div><?= $combattant_1->getName() ?> attaque <?= $combattant_2->getName() ?></div>
    <?php $combattant_1->attack( $combattant_2 ) ?>
    <div><?=  stats($combattant_1, $combattant_2) ?></div>


    <h3>Superman riposte d'une attaque suivi d'une super attaque</h3>
    <div><?= $combattant_2->getName() ?> riposte d'une attaque suivi d'une super attaque.</div>
    <?php 
        $combattant_2
            ->attack( $combattant_1 )
            ->superAttack( $combattant_1 ) 
    ?>
    <div><?=  stats($combattant_1, $combattant_2) ?></div>


    <h3>Batman – Furax – fait une super attaque</h3>
    <div><?= $combattant_1->getName() ?>  – Furax – fait une super attaque</div>
    <?php $combattant_1->superAttack( $combattant_2 ) ?>
    <div><?=  stats($combattant_1, $combattant_2) ?></div>


    <h3>Superman se soigne (il pleure)</h3>
    <div><?= $combattant_2->getName() ?> se soigne (il pleure)</div>
    <?php $combattant_2->care() ?>
    <div><?=  stats($combattant_1, $combattant_2) ?></div>
    

    <h3>Batman tente une attaque secrète</h3>
    <div><?= $combattant_1->getName() ?> tente une attaque secrète</div>
    <?php $combattant_1->secretAttack( $combattant_2 ) ?>
    <div><?=  stats($combattant_1, $combattant_2) ?></div>


    <h3>Superman encore affaiblie lance une double attaque </h3>
    <div><?= $combattant_2->getName() ?> encore affaiblie lance une double attaque </div>
    <?php 
        $combattant_2
            ->attack($combattant_1)
            ->attack($combattant_1)
    ?>
    <div><?=  stats($combattant_1, $combattant_2) ?></div>


    <h3>Batman répond d'une attaque simple suivi d'une attaque secrète</h3>
    <div><?= $combattant_1->getName() ?> répond d'une attaque simple suivi d'une attaque secrète</div>

    <?php $combattant_1->attack( $combattant_2 ) ?>
    <div><?=  stats($combattant_1, $combattant_2) ?></div>

    <?php $combattant_1->secretAttack( $combattant_2 ) ?>
    <div><?=  stats($combattant_1, $combattant_2) ?></div>


    <h3>Superman est au tapie et Batman gagne un point d'expérience.</h3>
    <div><?= $combattant_2->getName() ?> est au tapie et <?= $combattant_1->getName() ?> gagne un point d'expérience.</div>


    <?php $combattant_1->levelUp() ?>


    <hr>



    <fieldset>
        <legend>Personnage 1</legend>
        <div>Nom : <?= $combattant_1->getName() ?></div>
        <div>Points de vie : <?= $combattant_1->getHp() ?></div>
        <div>Experience : <?= $combattant_1->getXp() ?></div>
    </fieldset>

    <fieldset>
        <legend>Personnage 2</legend>
        <div>Nom : <?= $combattant_2->getName() ?></div>
        <div>Points de vie : <?= $combattant_2->getHp() ?></div>
        <div>Experience : <?= $combattant_2->getXp() ?></div>
    </fieldset>

</body>
</html>