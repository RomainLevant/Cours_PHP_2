<?php 

print_r( $argv );
