<?php 

namespace DirC;

class MaClasse
{
    public $property = "Dir C : MaClasse";
}