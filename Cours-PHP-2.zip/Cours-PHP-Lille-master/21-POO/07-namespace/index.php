<?php 

include_once "dir_a/MaClasse.php";
include_once "dir_b/MaClasse.php";
include_once "dir_c/MaClasse.php";

$maClasse_a = new \DirA\MaClasse;
$maClasse_b = new \DirB\MaClasse;
$maClasse_c = new \DirC\MaClasse;

echo $maClasse_a->property."<br>";
echo $maClasse_b->property."<br>";
echo $maClasse_c->property."<br>";