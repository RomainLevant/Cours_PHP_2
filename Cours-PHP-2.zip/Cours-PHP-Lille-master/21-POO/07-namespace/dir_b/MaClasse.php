<?php 

namespace DirB;

class MaClasse
{
    public $property = "Dir B : MaClasse";
}