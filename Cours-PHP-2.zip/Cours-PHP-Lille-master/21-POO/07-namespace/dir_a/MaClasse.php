<?php 

namespace DirA;

class MaClasse
{
    public $property = "Dir A : MaClasse";
}