<?php 

// On force l'affichage des messages d'erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class MaClass
{
    // Constants
    // --
    
    const MA_CONSTANTE = "Valeur de la constante.";

    
    // Properties
    // --

    public $propriete_1 = "Valeur de la propiete 1 !";
    public $propriete_2 = "Valeur de la propiete 2 !";


    // Methods
    // --

    public function methode_1()
    {
        return self::MA_CONSTANTE;
    }

    public function methode_2(string $argument): string
    {
        return strtoupper( $argument  );
    }

    public function modifieLaPropriete_1()
    {
        $this->propriete_1 = "Nouvelle valeur de la propriété 1 !";
    }
}

$maClass = new MaClass;


echo $maClass->propriete_1;
echo "<hr>";

$maClass->modifieLaPropriete_1();

echo $maClass->propriete_1;
echo "<hr>";

// echo $maClass->propriete_2;
// echo "<hr>";

// echo $maClass->methode_2("ma chaine de caractères !");
// echo "<hr>";

// echo MaClass::MA_CONSTANTE;
// echo "<hr>";

// echo $maClass->methode_1();
// echo "<hr>";

