<?php

// On force l'affichage des messages d'erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

class MaClasseParent
{
    const PARENT_CONSTANT = "Constante de la classe Parent";

    public $parent_property = "Propriété de la classe parent";

    public function parent_method()
    {
        return "Méthode de la classe parent";
    }
}

class MaClasseEnfant extends MaClasseParent
{
    const CHILD_CONSTANT = "Constante de la classe enfant";

    public $child_property = "Propriété de la classe enfant";

    public function child_method()
    {
        return "Méthode de la classe enfant";
    }

    public function child_second_method()
    {
        return $this->parent_method();
        // return parent::parent_method();
    }

    public function parent_method()
    {
        return "Méthode de la classe parent (chez l'enfant)";
    }
}

///////////////////////////////////////////////////////////////////////////////

$parent = new MaClasseParent;
$enfant = new MaClasseEnfant;


// La classe enfant possede les propriétés et methode du parent 
// --

echo MaClasseEnfant::PARENT_CONSTANT ."<br>";
echo $enfant->parent_property ."<br>";
echo $enfant->parent_method() ."<br>";

echo "<hr>";

echo MaClasseEnfant::CHILD_CONSTANT."<br>";
echo $enfant->child_property ."<br>";
echo $enfant->child_method() ."<br>";
echo $enfant->child_second_method() ."<br>";

echo "<hr>";

// /!\ La classe parent n'accède pas aux propriété et methodes de la classe enfant
// --

echo MaClasseParent::PARENT_CONSTANT ."<br>";
echo $parent->parent_property ."<br>";
echo $parent->parent_method() ."<br>";

echo "<hr>";

// 
// echo MaClasseParent::CHILD_CONSTANT."<br>";
// echo $parent->child_property ."<br>";
// echo $parent->child_method() ."<br>";
// echo $parent->child_second_method() ."<br>";

echo $enfant->parent_method() ."<br>";
