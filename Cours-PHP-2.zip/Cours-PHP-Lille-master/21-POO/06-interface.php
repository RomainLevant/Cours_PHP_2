<?php 

// On force l'affichage des messages d'erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


interface FirstnameInterface
{
    public function getFirstname(): string;
}

interface LastnameInterface
{
    public function getLastname(): string;
}

class Person implements FirstnameInterface, LastnameInterface
{
    private $firstname;
    private $lastname;

    public function __construct(string $firstname, string $lastname)
    {
        $this->firstname = $firstname;
        $this->lastname = $lastname;
    }

    public function getFirstname(): string
    {
        return $this->firstname;
    }

    public function getLastname(): string
    {
        return $this->lastname;
    }


}

class Employe extends Person
{
}


$employe_1 = new Employe("Bruce", "Wayne");
$employe_2 = new Employe("Bruce", "Baner");

echo $employe_1->getFirstname()."<br>";