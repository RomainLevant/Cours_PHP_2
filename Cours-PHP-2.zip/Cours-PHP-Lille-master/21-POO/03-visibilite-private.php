<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


class A 
{
    private $property = "Property of A";

    public function getProperty()
    {
        return $this->property;
    }
}

class B extends A
{
    public function getPropertyOfA()
    {
        return $this->property;
    }
}

////////////////////////////////////////////////////////////////////////////////

$a = new A;
echo $a->getProperty()."<br>";
// echo $a->property."<br>";

$b = new B;
// echo $b->property."<br>";
echo $b->getPropertyOfA()."<br>";

