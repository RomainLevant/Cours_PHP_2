<?php

class A 
{
    public $property = "Property of A";
}

class B extends A
{
    public function getPropertyOfA()
    {
        return $this->property;
    }
}

////////////////////////////////////////////////////////////////////////////////

$a = new A;
echo $a->property."<br>";

$b = new B;
echo $b->property."<br>";
echo $b->getPropertyOfA()."<br>";

