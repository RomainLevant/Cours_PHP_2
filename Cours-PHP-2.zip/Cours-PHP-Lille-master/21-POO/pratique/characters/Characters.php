<?php 

class Characters
{
    public $name;
    public $age = 0;

    public function __construct(string $new_name)
    {
        $this->name = $new_name;
    }

    public function __destruct()
    {
        
        echo "Desctruction de l'object ". $this->name."<br>";
    }

    // public function setName(string $new_name)
    // {
    //     $this->name = $new_name;
    // }
    // public function setAge(int $new_age)
    // {
    //     $this->age = $new_age;
    // }

    public function showName()
    {
        return $this->name;
    }
    public function showAge()
    {
        return $this->age;
    }
}