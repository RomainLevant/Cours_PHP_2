<?php 

include_once "Characters.php";

$perso_1 = new Characters("Bob");
$perso_2 = new Characters("Bruce");

echo "Nom Perso 1 : ". $perso_1->showName()."<br>";
echo "Age Perso 1 : ". $perso_1->showAge()."<br>";

unset($perso_2);

echo "<hr>";
echo "Nom Perso 2 : ". $perso_2->showName()."<br>";
echo "Age Perso 2 : ". $perso_2->showAge()."<br>";

echo "<hr>";
echo "<hr>";

// $perso_1->setName("Bob");
// $perso_2->setName("Bruce");

// echo "Nom Perso 1 : ". $perso_1->showName()."<br>";
// echo "Nom Perso 2 : ". $perso_2->showName()."<br>";


// echo $perso_1->showName() ."<br>";