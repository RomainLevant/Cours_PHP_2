<?php 

// Inclus le fichier "Personnage.php" qui contient la déclaration de la classe "Personnage"
include_once "Personnage.php";

// Création de l'instance du personnage.
$personnage = new Personnage;

// Affiche le "$nom" du "personnage"
echo "Nom : ". $personnage->nom."<br>";

// Le personnage dit bonjour à Claire
echo $personnage->ditBonjour("Claire");

// Le personnage dit bonjour à Doug
echo $personnage->ditBonjour("Doug");

// Le personnage dit au revoir
echo $personnage->ditAurevoir();