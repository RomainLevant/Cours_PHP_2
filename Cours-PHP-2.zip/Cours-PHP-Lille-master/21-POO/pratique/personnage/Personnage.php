<?php

class Personnage
{
    public $nom = "Francis";
    public $age = 53;

    public function ditBonjour(string $prenom)
    {
        return "Bonjour $prenom.<br>";
    }

    public function ditAurevoir()
    {
        return "Au revoir !<br>";
    }
}