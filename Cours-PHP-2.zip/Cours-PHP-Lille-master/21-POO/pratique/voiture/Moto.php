<?php 

class Moto 
{
    const WHEELS = 2;
}