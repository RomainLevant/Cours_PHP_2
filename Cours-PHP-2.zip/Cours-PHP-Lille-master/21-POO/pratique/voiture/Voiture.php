<?php 

class Voiture
{
    const WHEELS = 4;
}