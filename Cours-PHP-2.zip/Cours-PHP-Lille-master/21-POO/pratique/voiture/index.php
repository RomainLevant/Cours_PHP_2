<?php 

include_once "Voiture.php";
include_once "Moto.php";

echo "Nombre de roues d'une voiture : ". Voiture::WHEELS .".<br>";
echo "Nombre de roues d'une moto : ". Moto::WHEELS .".<br>";