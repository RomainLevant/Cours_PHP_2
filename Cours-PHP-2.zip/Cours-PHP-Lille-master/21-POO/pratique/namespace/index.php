<?php 

include_once "vendor/github/Utils.php";
include_once "vendor/github/Truc.php";
include_once "vendor/osw3/Utils.php";
include_once "vendor/Test.php";

use \osw3\Utils AS U1;
use \github\Utils AS U2;

$utils_a = new U1;
$utils_b = new U2;

echo $utils_a->ZeroFill(5);