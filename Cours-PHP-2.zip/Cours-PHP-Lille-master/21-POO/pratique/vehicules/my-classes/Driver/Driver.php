<?php 

namespace Driver;

echo "Fichier Driver";

class Driver 
{
    private $firstname;
    private $lastname;

    public function __construct(string $firstname, string $lastname)
    {
        $this->setFirstname( $firstname );
        $this->setLastname( $lastname );
    }

    /**
     * Get the value of firstname
     */ 
    public function getFirstname()
    {
        return $this->firstname;
    }

    /**
     * Set the value of firstname
     *
     * @return  self
     */ 
    public function setFirstname($firstname)
    {
        $firstname = strtolower( $firstname );
        $firstname = ucwords( $firstname );

        $this->firstname = $firstname;

        return $this;
    }

    /**
     * Get the value of lastname
     */ 
    public function getLastname()
    {
        return $this->lastname;
    }

    /**
     * Set the value of lastname
     *
     * @return  self
     */ 
    public function setLastname($lastname)
    {
        $lastname = strtoupper( $lastname );

        $this->lastname = $lastname;

        return $this;
    }
}