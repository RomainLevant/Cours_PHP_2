<?php 

namespace Vehicule;

class Moto extends Vehicule  
{
    const WHEELS = 2;

    public function ethylotest(int $s=10)
    {
        echo "souffle $s secondes dans le ballon !";
    }
}