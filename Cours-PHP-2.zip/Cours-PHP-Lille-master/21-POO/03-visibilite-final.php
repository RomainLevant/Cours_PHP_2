<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


class A 
{
    protected $property = "Property of A";

    final public function getProperty()
    {
        return $this->property;
    }
}

class B extends A
{
    // public function getProperty()
    // {
    //     return strtoupper($this->property);
    // }
}

////////////////////////////////////////////////////////////////////////////////

$a = new A;
echo $a->getProperty()."<br>";

$b = new B;
echo $b->getProperty()."<br>";

