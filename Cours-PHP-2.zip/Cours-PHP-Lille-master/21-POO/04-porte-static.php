<?php 

// On force l'affichage des messages d'erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);



class A 
{
    // Une constante possède la portée STATIC
    const MA_CONSTANTE = "Valeur de la constante";

    // Une propriété static 
    public static $ma_propriete = "Valeur de la propriété";

    private $seconde_propriete = "Valeur de la seconde propriété";

    // Une methode static 
    public static function ma_methode()
    {
        return "Valeur de la methode";
    }

    // Une methode static n'accede pas à "$this"
    public static function ma_seconde_methode()
    {
        // return $this->seconde_propriete;
    }

}

class B
{
    // Une constante possède la portée STATIC
    const MA_CONSTANTE = "Valeur de la constante";

    // Une propriété static 
    public static $ma_propriete = "Valeur de la propriété";

    // Une methode static 
    public static function ma_methode()
    {
        return "Valeur de la methode";
    }
}


////////////////////////////////////////////////////////////////////////////////


echo A::MA_CONSTANTE."<br>";

echo A::$ma_propriete."<br>";

A::$ma_propriete = "Nouvelle valeur";

echo A::$ma_propriete."<br>";

echo A::ma_methode()."<br>";
echo A::ma_seconde_methode()."<br>";

echo "<hr>";


// $a = new A;

// // echo $a->MA_CONSTANTE."<br>";

// // echo $a->ma_propriete."<br>";

// echo $a->ma_methode()."<br>";
// echo A::ma_methode()."<br>";
