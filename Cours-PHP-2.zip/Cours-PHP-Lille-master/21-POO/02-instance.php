<?php 

// Declaration
class MouleGateau {} 

// Instance (création de l'objet)
$mouleGateau = new MouleGateau();

$gateauChoco = new MouleGateau();
$gateauFraise = new MouleGateau();
