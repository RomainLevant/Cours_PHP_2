<?php

class MaClass {}
